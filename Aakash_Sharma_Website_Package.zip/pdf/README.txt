Apni PDF files is folder mein rakhein. Phir index.html ke PDF section mein har PDF ke liye link add karna hoga. Udaharan: <a href='pdf/biology-notes.pdf'>Biology Notes PDF dekhein</a>
